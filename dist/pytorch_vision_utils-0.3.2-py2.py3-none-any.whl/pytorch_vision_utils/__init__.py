import os

version='0.3.2'

os.system("pip install -r requirements.txt")

import pretrainedmodels