import os

print("Installing required packages...")
os.system("pip install -r requirements.txt")