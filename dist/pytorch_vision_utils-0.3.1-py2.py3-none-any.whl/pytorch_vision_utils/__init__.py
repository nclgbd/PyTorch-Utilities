import os

version='0.3.1'

os.system("pip install -r requirements.txt")

import pretrainedmodels