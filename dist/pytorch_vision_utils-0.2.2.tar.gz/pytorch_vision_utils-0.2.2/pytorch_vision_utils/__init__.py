import os

# Have to manually install
import pretrainedmodels

os.system("pip install -r requirements.txt")

