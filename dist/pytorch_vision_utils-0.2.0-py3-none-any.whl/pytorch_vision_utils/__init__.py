import os

print("Checking for and/or installing required packages...")
os.system("pip install -r requirements.txt")
print("Complete!")