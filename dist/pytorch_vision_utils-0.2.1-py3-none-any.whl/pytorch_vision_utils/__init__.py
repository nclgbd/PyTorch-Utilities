import os
# from pretrainedmodels.models.

os.system("pip install -r requirements.txt")